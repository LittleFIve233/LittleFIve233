#ifndef LZ11_H
#define LZ11_H

#include "../types.h"

void* lz11_compress(u32* size, void* input, u32 inputSize);

#endif