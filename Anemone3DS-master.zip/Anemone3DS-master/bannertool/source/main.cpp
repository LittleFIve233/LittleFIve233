#include "cmd.h"

int main(int argc, char* argv[]) {
    return cmd_process_command(argc, argv);
}