#ifndef CMD_H
#define CMD_H

int cmd_process_command(int argc, char* argv[]);

#endif