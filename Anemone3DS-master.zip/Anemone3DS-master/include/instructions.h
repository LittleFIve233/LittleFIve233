/*
*   This file is part of Anemone3DS
*   Copyright (C) 2016-2020 Contributors in CONTRIBUTORS.md
*
*   This program is free software: you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation, either version 3 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*
*   Additional Terms 7.b and 7.c of GPLv3 apply to this file:
*       * Requiring preservation of specified reasonable legal notices or
*         author attributions in that material or in the Appropriate Legal
*         Notices displayed by works containing it.
*       * Prohibiting misrepresentation of the origin of that material,
*         or requiring that modified versions of such material be marked in
*         reasonable ways as different from the original version.
*/

#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

#include "draw.h"
#include "colors.h"

Instructions_s normal_instructions[MODE_AMOUNT] = {
    {
        .info_line = NULL,
        .instructions = {
            {
                "按住 \uE000 安装主题",
                "按下 \uE001 选为随机主题"
            },
            {
                "按住 \uE002 查看更多",
                "按下 \uE003 预览主题"
            },
            {
                "按下 \uE004 选择开机画面",
                "按下 \uE005 扫描QR码"
            },
            {
                "退出",
                "从SD卡删除"
            }
        }
    },
    {
        .info_line = NULL,
        .instructions = {
            {
                "按下 \uE000 安装开机画面",
                "按下 \uE001 删除已安装开机画面"
            },
            {
                "按住 \uE002 查看更多",
                "按下 \uE003 预览开机画面"
            },
            {
                "按下 \uE004 选择主题",
                "按下 \uE005 扫描QR码"
            },
            {
                "退出",
                "从SD卡删除"
            }
        }
    }
};

Instructions_s install_instructions = {
    .info_line = "松开 \uE000 取消或按住 \uE006 并松开 \uE000 安装",
    .instructions = {
        {
            "\uE079 安装主题",
            "\uE07A 安装随机主题"
        },
        {
            "\uE07B 安装仅主题BGM",
            "\uE07C 安装无主题BGM"
        },
        {
            NULL,
            NULL
        },
        {
            "退出",
            NULL
        }
    }
};

Instructions_s extra_instructions[3] = {
    {
        .info_line = "松开 \uE002 取消或按住 \uE006 并松开 \uE002 排序",
        .instructions = {
            {
                "\uE079 按名称排序",
                "\uE07A 按作者排序"
            },
            {
                "\uE07B 按文件名排序",
                NULL
            },
            {
                NULL,
                NULL
            },
            {
                "退出",
                NULL
            }
        }
    },
    {
        .info_line = "松开 \uE002 取消或按住 \uE006 并松开 \uE002 添加随机主题",
        .instructions = {
            {
                "\uE079 跳转列表",
                "\uE07A 重新加载图标"
            },
            {
                "\uE07B 浏览ThemePlaza",
                NULL
            },
            {
                "\uE004 排序菜单",
                "\uE005 Dump菜单"
            },
            {
                "退出",
                NULL
            }
        }
    },
    {
        .info_line = "松开 \uE002 取消或按住 \uE006 并释放 \uE002 来dump",
        .instructions = {
            {
                "\uE079 Dump当前的主题",
                "\uE07A Dump所有主题"
            },
            {
                NULL,
                NULL
            },
            {
                NULL,
                NULL
            },
            {
                "退出",
                NULL
            }
        }
    }
};

#endif
