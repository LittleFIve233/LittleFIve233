# Main Contributors
* Alex Taber ([@astronautlevel2](https://github.com/astronautlevel2))
* Théo B. ([@LiquidFenrir](https://github.com/LiquidFenrir))
* Dawid Eckert ([@daedreth](https://github.com/daedreth))
* Dylan G. ([@helloman892](https://github.com/helloman892))
* Nils P. ([@ZetaDesigns](https://github.com/ZetaDesigns))
* Matt Kenny ([@KennLDN](https://github.com/KennLDN))

# Minor Contributors
* Nic ([@Wizzrobes](https://github.com/Wizzrobes))
* [@saibotu](https://github.com/saibotu)
* Jeremy Postelnek ([@TurtleP](https://github.com/TurtleP))
* [@FrozenChen](https://github.com/FrozenChen)
* Luís Marques ([@luigoalma](https://github.com/luigoalma))
* [@uyuiyu](https://github.com/uyuiyu)
* Guillaume Gérard ([@GreatWizard](https://github.com/GreatWizard))
* Joel ([@joel16](https://github.com/joel16))
* [@thedax](https://github.com/thedax)
* [@Wryyyong](https://github.com/Wryyyong)
